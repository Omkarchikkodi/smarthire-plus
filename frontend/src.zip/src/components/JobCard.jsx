export default function JobCard({ job }) {
  return (
    <div className="bg-white p-4 rounded shadow mb-4">
      <h2 className="text-lg font-semibold">{job.title}</h2>
      <p className="text-sm text-gray-600">{job.location}</p>

      <div className="mt-2">
        <p className="text-blue-600 font-bold">
          Match Score: {job.match_score}%
        </p>
      </div>

      <div className="mt-2">
        <p className="text-sm font-semibold">Skills Required:</p>
        <p className="text-sm text-gray-700">
          {job.skills_required.slice(0, 8).join(", ")}
        </p>
      </div>
    </div>
  );
}
