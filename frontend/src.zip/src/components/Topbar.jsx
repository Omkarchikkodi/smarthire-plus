export default function Topbar() {
  return (
    <div className="w-full p-4 bg-white shadow flex items-center justify-between">
      <h1 className="text-xl font-bold">SmartHire+</h1>
    </div>
  );
}
